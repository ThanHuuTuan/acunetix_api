# coding=utf-8
import time

from core.configuration import settings
from core.functions import convert_utf8
from core.plugins import Plugin
from .acunetix_lib.acunetix import AcunetixScaner


class SboxPlugin(Plugin):
    def __init__(self, scan_info, plugin_info, web_api):
        self.acunetix = None
        self.host_vuln_map = {}
        self.list_vuln_acunetix = []
        self.crawldata = {}
        Plugin.__init__(self, scan_info, plugin_info, web_api)
        self.my_ip = []

    def get_plugin_options(self):
        self.options = convert_utf8(settings.load_config("acunetix.json"))
        self.arguments = self.set_arguments(self.options)
        self.acunetix = AcunetixScaner(self.options)
        self.name = self.options["name"]

    def set_arguments(self, option):
        arguments = option["options_target"][str(self.speed)]
        arguments["custom_headers"] = self.custom_headers
        if isinstance(self.custom_cookies, list):
            for cookie in self.custom_cookies:
                if "url" in cookie and "value" in cookie:
                    set_cookie = {"url": cookie["url"], "cookie": cookie["value"]}
                    arguments["custom_cookies"].append(set_cookie)
        arguments = self.set_proxy(arguments)
        return arguments

    def set_proxy(self, arguments):
        try:
            get_proxy = self.web_api.get_proxy()
            if get_proxy is not None:
                # set_proxy = self.options["proxy"]
                if get_proxy["enable"] and get_proxy["test_connection"]:
                    arguments["proxy"]["enabled"] = True
                    arguments["proxy"]["address"] = get_proxy["address"]
                    arguments["proxy"]["port"] = get_proxy["port"]
                    arguments["proxy"]["protocol"] = get_proxy["protocol"]

                    if get_proxy["username"] is not None and get_proxy["password"] is not None:
                        arguments["proxy"]["username"] = get_proxy["username"]
                        arguments["proxy"]["password"] = get_proxy["proxy"]["password"]
        except:
            self.notify(message="Lỗi cấu hình proxy của " + self.options["name_vi"])
        return arguments

    #def check_stop(self):
    #     return False

    def scan(self):
        self.info_log(message="Start scan")
        self.notify(message="Bắt đầu " + self.options["name_vi"])
        try:
            self.get_host_list()
            if len(self.list_host.keys()) == 0:
                for address in self.list_address:
                    self.get_excluded_domain()
                    self.create_new_host(address)
                self.get_host_list()
            for address in self.list_host.keys():
                if self.check_stop():
                    self.info_log(message="Stop scan")
                    self.notify(message="Dừng " + self.options["name_vi"])
                    return self.check_error
                self.scan_object(address=address)
                self.acunetix.delete_target()
            self.acunetix.logout()
        except Exception, ex:
            self.error_log(message="Error: " + ex.message)
            self.notify(message="Không thể " + self.options["name_vi"], status=2)
            self.check_error = 2

        self.info_log(message="Finish scan")
        self.finish_scan(self.check_error)
        return self.check_error

    def scan_object(self, address):
        host_id = self.list_host[address]
        try:
            scan_id = self.acunetix.scan(address, options=self.arguments,
                                         scan_id=None)
            if scan_id is not None:
                self.host_vuln_map[address] = {}
                self.wait_for_finish(scan_id, host_id, address)
        except:
            self.error_log("Scan is error, can not create scan.")
            return

    def create_new_host(self, address):
        domain = self.parse_addr(address)
        if domain in self.excluded_domain:
            self.error_log(message="Not scan, excluded domain {0}".format(domain), address=address)
            self.notify(message="Không thể " + self.options["name_vi"] + " với domain: " + str(domain), status=1)
            return
        host_data = {
            "ip_addr": address,
            "task": self.task
        }
        return self.web_api.post_host(host_data)

    def wait_for_finish(self, scan_id, host_id, address):
        # time.sleep(settings.config["plugins"]["time_delay"])
        crawldata_check = 0
        while True:
            if self.check_stop():
                list_vuln = self.acunetix.get_list_vuln()
                if list_vuln is not None:
                    self.update_service(list_vuln, host_id)
                self.crawldata_scan(website=host_id, address=address)
                self.acunetix.stop_scan(scan_id)
                self.info_log(message="Scan is stopped by user")
                self.notify(message="Dừng " + self.options["name_vi"])
                return True
            else:
                check_stop = self.acunetix.check_stop(scan_id)
                if check_stop != 0:
                    if check_stop == -1:
                        self.check_error = 2
                    list_vuln = self.acunetix.get_list_vuln()
                    if list_vuln is not None:
                        self.update_service(list_vuln, host_id)
                    self.crawldata_scan(website=host_id, address=address)
                    return True
                else:
                    list_vuln = self.acunetix.get_list_vuln()
                    if list_vuln is not None:
                        self.update_service(list_vuln, host_id)
                    else:
                        print "vulnerability acunetix is None"
                    if crawldata_check == 0:
                        self.crawldata_scan(website=host_id, address=address)
                        crawldata_check += 1
                    else:
                        if crawldata_check == 4:
                            crawldata_check = 0
                        else:
                            crawldata_check += 1
                    print "waitting ... ! " + str(address) + ", scan_id: " + str(scan_id)
                    time.sleep(settings.config["plugins"]["time_delay"])

    def crawldata_scan(self, website, address):
        list_created_crawl = [0]
        if address[-1] == "/":
            address = address[:-1]
        while len(list_created_crawl) > 0:
            parent_id = list_created_crawl.pop()
            parents = self.acunetix.crawldata_scan(parent_id)
            for parent in parents:
                if parent["loc_id"] not in self.crawldata:
                    self.crawldata_detail(parent=parent, address=address, website=website, parent_id=parent_id)
                list_created_crawl.append(parent["loc_id"])

    def crawldata_detail(self, parent, address, website, parent_id=0):
        try:
            if parent_id in self.crawldata:
                parent_id = self.crawldata[parent_id]
            else:
                parent_id = 0
            if parent["loc_id"] not in self.crawldata:
                path = address + parent["path"]
                if parent["loc_type"] == "folder":
                    loc_type = 1
                else:
                    loc_type = 0
                crawl = self.get_crawl(path=path, website=website)
                # print crawl
                if crawl is not None and "id" in crawl:
                    self.crawldata[parent["loc_id"]] = crawl["id"]

                    return crawl["id"]
                elif isinstance(crawl, list) and len(crawl) > 0 and "id" in crawl[0]:
                    self.crawldata[parent["loc_id"]] = crawl[0]["id"]
                    return crawl[0]["id"]
                else:
                    crawl = self.create_crawl(path=path, name=parent["name"], website=website, loc_type=loc_type,
                                              parent_id=parent_id)
                    # print crawl
                    if crawl is not None and "id" in crawl:
                        self.crawldata[parent["loc_id"]] = crawl["id"]
                        return crawl["id"]
            return None
        except:
            print "not create crawldata : " + str(parent)
            return None

    def create_crawl(self, path, name, parent_id, loc_type, website):
        data = {
            "path": path,
            "name": name,
            "parent_id": parent_id,
            "loc_type": loc_type,
            "website": website
        }

        return self.web_api.post_crawl(data=data)

    def get_crawl(self, path, website):
        return self.web_api.get_crawl(path=path, website=website)

    def update_service(self, list_vuln, host_id):
        if list_vuln is not None and isinstance(list_vuln, list):
            for vuln in list_vuln:
                if vuln["vuln_id"] not in self.list_vuln_acunetix:
                    vuln_acunetix_info = self.acunetix.get_vuln_info(vuln["vuln_id"])
                    if vuln_acunetix_info is None:
                        self.info_log(message="Not found vulnerability acunetix: {}".format(str(vuln["vuln_id"])))

                    else:
                        vuln_acunetix_info = convert_utf8(vuln_acunetix_info)
                        if vuln_acunetix_info["vt_name"] not in self.vuln_map:
                            vuln_info = self.web_api.get_vuln(vuln_acunetix_info["vt_name"],
                                                              self.id)
                            if isinstance(vuln_info, dict) and "id" in vuln_info:
                                vuln_id = vuln_info["id"]
                            else:
                                cve = []
                                for tag in vuln_acunetix_info["tags"]:
                                    if "CWE" in tag:
                                        cve.append(tag)
                                vuln_info = self.create_vuln(name=vuln_acunetix_info["vt_name"],
                                                             synopsis=vuln_acunetix_info["description"],
                                                             description=vuln_acunetix_info["long_description"],
                                                             solution=vuln_acunetix_info["recommendation"],
                                                             ref=[references["href"] for references in
                                                                  vuln_acunetix_info["references"]],
                                                             cve=cve,
                                                             cvss=str(vuln_acunetix_info["cvss_score"]),
                                                             severity=vuln_acunetix_info["severity"] + 1,
                                                             protocol="tcp",
                                                             family="Web Servers",
                                                             tags=vuln_acunetix_info["tags"],
                                                             impact=vuln_acunetix_info["impact"])

                                if isinstance(vuln_info, dict) and "id" in vuln_info:
                                    vuln_id = vuln_info["id"]
                                else:
                                    self.error_log(message="Not Create vulnerability {} in database".format(
                                        vuln_acunetix_info["vt_name"]))
                                    continue
                                self.info_log(message="Create vulnerability {} in database".format(
                                    vuln_acunetix_info["vt_name"]))

                            if vuln_acunetix_info["vt_name"] not in self.vuln_map and vuln_id is not None:
                                self.vuln_map[str(vuln_acunetix_info["vt_name"])] = vuln_id
                        else:
                            vuln_id = self.vuln_map[str(vuln_acunetix_info["vt_name"])]
                        try:
                            # host_vulnerability_info = self.web_api.find_host_vuln(host_id,
                            #                                                       vuln["vuln_id"])
                            host_vulnerability_info = []
                            if isinstance(host_vulnerability_info, list) and len(host_vulnerability_info) == 0:
                                host_vuln = self.create_host_vuln(host_id=host_id, vulnerability=vuln_id,
                                                                  port=0,
                                                                  attack_details=vuln_acunetix_info["details"],
                                                                  request=self.cover_request(
                                                                      vuln_acunetix_info["request"]),
                                                                  output="",
                                                                  scanner_vuln_id=str(vuln["vuln_id"]),
                                                                  scanner_scan_id=str(time.time()),
                                                                  affects=vuln_acunetix_info["affects_url"],
                                                                  param=vuln_acunetix_info.get("affects_detail", ""))
                                if isinstance(host_vuln, dict) and "id" in host_vuln:
                                    self.info_log(message="Create host vulnerability with vuln {} in database".format(
                                        vuln_acunetix_info["vt_name"]))
                                else:
                                    self.error_log(
                                        message="Not Create host vulnerability with vuln {} in database".format(
                                            vuln_acunetix_info["vt_name"]))
                            # else:
                            #     self.info_log(message="Found host vulnerability with vuln_id {} in database".format(
                            #         str(vuln_id)))
                            self.list_vuln_acunetix.append(vuln["vuln_id"])
                        except:
                            self.error_log(message="Not Create host vulnerability with vuln {} in database".format(
                                vuln_acunetix_info["vt_name"]))

    def cover_request(self, request):
        list_request = str(request).split("\n")
        results = []
        for header in list_request:
            if "Acunetix" not in header:
                results.append(header)
        return "\n".join(results)
