# !/usr/bin/env python
# -*- coding: utf-8 -*-
import hashlib
import json
import os
from time import sleep

from requests import RequestException
from retrying import retry

from core.email_notify import sent_email
from core.logger import logger
from core.network_connector import NetworkConnection


class AcunetixAPI:
    def __init__(self, settings, scan_id=None):
        self.headers = {"Accept": "application/json, text/plain, */*",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/66.4.104 Chrome/60.4.3112.104 Safari/537.36",
                        "Connection": "keep-alive",
                        # "Cookie": "",
                        "content-type": "application/json; charset=utf8",
                        "X-Auth": os.environ.get("X-Auth", settings.get("login").get("X-Auth", ""))
                        }
        self.settings = settings
        self.acunetix_server = NetworkConnection(
            str(os.environ.get("ACU_HOST", settings["acunetix_server"]["server_address"])),
            str(os.environ.get("ACU_POST", settings["acunetix_server"]["port"])),
            is_https=settings["acunetix_server"]["https"])
        self.scan_id = scan_id
        self.target_id = None
        self.login()

    @retry(wait_random_min=15000, wait_random_max=30000)
    def login(self, auth=None):
        if auth is None:
            auth = self.settings["login"]
        data = {
            "email": str(os.environ.get("ACU_EMAIL", auth["email"])),
            "password": hashlib.sha256(str(os.environ.get("ACU_PASS", auth["password"]))).hexdigest(),
            "remember_me": auth["remember_me"],
            "logout_previous": True
        }
        response = self.acunetix_server.connect("POST", "/api/v1/me/login", data=json.dumps(data))
        status_code = response.status_code
        if status_code == 204:
            user_info = response.headers
            if "X-Auth" in user_info:
                auth = user_info["X-Auth"]
                self.headers["X-Auth"] = auth
                self.headers["Cookie"] = "ui_session=" + auth
                logger.log("Login Acunetix Successful!")

        else:
            logger.error("acunetix service: cannot login to acunetix service, status code = " + str(status_code),
                         plugin=self.settings["name"])
            raise RequestException("acunetix service: cannot login to acunetix service, retrying ....",
                                   plugin=self.settings["name"])

    def logout(self):
        uri = "/api/v1/me/logout"
        self.connect("GET", uri, headers=self.headers)

    @retry(wait_random_min=15000, wait_random_max=30000)
    def connect(self, method, uri, headers=None, data=None, files=None, stream=None):
        if headers is None:
            headers = self.headers
        r = self.acunetix_server.connect(method, uri, headers=headers, data=data, files=files,
                                         stream=stream)
        if r is not None:
            if r.status_code == 401:
                self.login()
                r = self.acunetix_server.connect(method, uri, headers=headers, data=data, files=files,
                                                 stream=stream)
            elif r.status_code >= 500:
                logger.error("Acunetix service: Cannot connect to web service, retrying ...",
                             plugin=self.settings["name"])
                raise RequestException("Acunetix service: Cannot connect to web service, retrying...",
                                       plugin=self.settings["name"])
        return r

    # task manager api
    def create_new_targets(self, url, data=None):
        if url is None:
            return ""
        if data is None:
            data = self.settings["new_target"]
        uri = "/api/v1/targets"
        data["address"] = url
        data["description"] = "sbox scanner: " + str(url)
        headers = {"Accept": "application/json, text/plain, */*",
                   "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/66.4.104 Chrome/60.4.3112.104 Safari/537.36",
                   "Connection": "keep-alive",
                   # "Cookie": "",
                   "content-type": "application/json; charset=utf8",
                   "X-Auth": os.environ.get("X-Auth", self.settings.get("login").get("X-Auth", ""))}
        r = self.connect("POST", uri, headers=self.headers, data=json.dumps(data))
        status_code = r.status_code
        if status_code != 201:
            return None
        target_id = r.json()["target_id"]
        self.target_id = target_id
        return self.target_id

    def config_target(self, target_id, data):
        uri = "/api/v1/targets/" + str(target_id) + "/configuration"
        # data = settings.config["acunetix"]["options_target"]
        r = self.connect("PATCH", uri, headers=self.headers, data=json.dumps(data))
        status_code = r.status_code
        if status_code != 204:
            return False
        return True

    def start_scan(self, options, url, data=None):
        if url is not None:
            target_id = self.create_new_targets(url)
            # target_id = "a9d75a60-e087-4b84-bf11-2d20cf5c776c"
            if target_id is None:
                return None
            if not self.config_target(target_id=target_id, data=options):
                return None
            if data is None:
                data = self.settings["options_scans"]
            data["target_id"] = target_id
            try:
                uri = "/api/v1/scans"
                response = self.connect("POST", uri, headers=self.headers, data=json.dumps(data))
                status_code = response.status_code
                if status_code != 200 and status_code != 201:
                    if status_code == 403:
                        data_response = response.json()
                        if "message" in data_response:
                            if data_response["message"] == "Feature not allowed":
                                sent_email(
                                    message="<br/>Xin chào!!<br/>Không thể quét website <strong>{}</strong><br/>Acunetix không được <strong>activated</strong>. Vui lòng cập nhật license để tiếp tục sử dụng".format(
                                        str(url)))
                    return None
                headers = response.headers
                if "Location" in headers:
                    scan_url = headers["Location"]
                    self.scan_id = scan_url[14:]

                    return self.scan_id
                else:
                    return None
            except Exception as e:
                logger.error("/api/v1/scans/ error: " + str(e), plugin=self.settings["name"])
                return None

    def getscan(self):
        targets = []
        try:
            uri = "/api/v1/scans/"
            response = self.connect("GET", uri, headers=self.headers)
            status_code = response.status_code
            if status_code != 200:
                return ""
            results = json.loads(response.content)
            for result in results['scans']:
                targets.append(result['target']['address'])
                # print result['scan_id'], result['target']['address'] # ,result['target_id']
            return list(set(targets))
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])

    def get_scan_detail(self, scan_id=None):
        try:
            if scan_id is None:
                scan_id = self.scan_id
            uri = "/api/v1/scans/" + str(scan_id)
            response = self.connect("GET", uri, headers=self.headers)
            status_code = response.status_code
            if status_code != 200:
                return ""
            result = json.loads(response.content)
            return result
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return -1

    def get_status(self, scan_id=None):
        try:
            if scan_id is None:
                scan_id = self.scan_id
            uri = "/api/v1/scans/" + str(scan_id)
            response = self.connect("GET", uri, headers=self.headers)
            status_code = response.status_code
            if status_code != 200:
                return ""
            result = json.loads(response.content)
            status = result['current_session']['status']
            return status
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return -1

    @retry(wait_random_min=5000, wait_random_max=10000)
    def getreports(self, scan_id=None):
        if scan_id is None:
            scan_id = self.scan_id
        print("getreports: " + str(scan_id))
        results_scan = self.results_scan(scan_id)
        if results_scan is None:
            return None
        data = {"export_id": "21111111-1111-1111-1111-111111111111",
                "source": {"list_type": "scan_result", "id_list": [results_scan]}}
        try:
            sleep(10)
            uri = "/api/v1/exports"
            response = self.connect("POST", uri, headers=self.headers, data=json.dumps(data))
            status_code = response.status_code
            if status_code != 201:
                return None
            report_id = response.json()["report_id"]
            download = None
            check = 3
            while download is None and check > 0:
                sleep(10)
                check -= 1
                uri_exports = "/api/v1/exports/" + str(report_id)
                response = self.connect("GET", uri_exports, headers=self.headers)
                result = response.json()
                if "download" in result:
                    if type(result["download"]) == type([]):
                        download = result["download"][0]
            if download is None:
                return None
            addheaders = self.headers
            addheaders[
                "Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
            report_file = self.connect("GET", download, headers=addheaders, stream=True)
            return report_file.content
        except Exception as e:
            logger.error("Error report " + str(e), plugin=self.settings["name"])
            return None
            # self.delete_scan(scan_id)

    def delete_scan(self, scan_id=None):
        try:
            if scan_id is None:
                scan_id = self.scan_id
            uri = "/api/v1/scans/" + str(scan_id)
            response = self.connect("DELETE", uri, headers=self.headers)
            if response.status_code == 204:
                return True
            else:
                return False
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return -1

    def stop_scan(self, scan_id=None):
        if scan_id is None:
            scan_id = self.scan_id
        try:
            uri = "/api/v1/scans/" + str(scan_id) + "/abort"
            response = self.connect("POST", uri, headers=self.headers)
            if response.status_code != 200 and response.status_code != 204:
                return False
            else:
                return True
        except Exception as e:
            logger.error(str(e))
            return -1

    def delete_target(self, target_id=None):
        try:
            if target_id is None:
                target_id = self.target_id
            uri = "/api/v1/targets/" + str(target_id)
            response = self.connect("DELETE", uri, headers=self.headers)
            if response.status_code == 204:
                return True
            else:
                return False
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return -1

    def statistics_scan(self, scan_id=None):
        try:
            if scan_id is None:
                scan_id = self.scan_id
            uri = "/api/v1/scans/" + str(scan_id) + "/results/" + str(
                self.results_scan(scan_id)) + "/statistics"
            response = self.connect("GET", uri, headers=self.headers)
            if response.status_code != 200:
                return ""
            return response.json()
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return -1

    def results_scan(self, scan_id):
        try:
            uri = "/api/v1/scans/" + str(scan_id) + "/results"
            response = self.connect("GET", uri, headers=self.headers)
            if response.status_code != 200:
                return None
            result_id = response.json()["results"][0]["result_id"]
            return result_id
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return None

    def crawldata_scan(self, scan_id, loc_id, result_id=None):
        try:
            if result_id is None:
                result_id = self.results_scan(scan_id)
            uri = "/api/v1/scans/" + str(scan_id) + "/results/" + str(result_id) + "/crawldata/" + str(
                loc_id) + "/children"
            response = self.connect("GET", uri, headers=self.headers)
            if response.status_code != 200:
                return []
            if isinstance(response.json(), dict) and "locations" in response.json():
                return response.json()["locations"]
            return []
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return []

    def vulnerabilities(self, scan_id, result_id=None):
        try:
            if result_id is None:
                result_id = self.results_scan(scan_id)
            uri = "/api/v1/scans/" + str(scan_id) + "/results/" + str(result_id) + "/vulnerabilities"
            response = self.connect("GET", uri, headers=self.headers)
            if response.status_code != 200:
                return None
            vulnerabilities = response.json()["vulnerabilities"]
            next_cursor = response.json()["pagination"]["next_cursor"]
            while next_cursor is not None:
                _uri = "/api/v1/scans/" + str(scan_id) + "/results/" + str(result_id) + "/vulnerabilities?c={}".format(
                    str(response.json()["pagination"]["next_cursor"]))
                response = self.connect("GET", _uri, headers=self.headers)
                if response.status_code == 200:
                    vulnerabilities += response.json()["vulnerabilities"]
                    next_cursor = response.json()["pagination"]["next_cursor"]
                else:
                    next_cursor = None
                    return vulnerabilities
            return vulnerabilities
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return None

    def vulnerabilities_info(self, scan_id, vuln_id, result_id=None):
        try:
            if result_id is None:
                result_id = self.results_scan(scan_id)
            uri = "/api/v1/scans/" + str(scan_id) + "/results/" + str(result_id) + "/vulnerabilities/" + str(vuln_id)
            response = self.connect("GET", uri, headers=self.headers)
            if response.status_code != 200:
                return None
            return response.json()
        except Exception as e:
            logger.error(str(e), plugin=self.settings["name"])
            return None

            # def get_path(self, path):
            #     # Check directory is exits
            #     absolute_path = path
            #     if os.path.abspath(path):
            #         absolute_path = os.path.join(settings.current_path, path)
            #     if os.path.isfile(absolute_path):
            #         if not os.path.exists(os.path.dirname(absolute_path)):
            #             os.makedirs(os.path.dirname(absolute_path))
            #     else:
            #         if not os.path.exists(absolute_path):
            #             os.makedirs(absolute_path)
            #     return absolute_path

# Acunetix_API = singleton(AcunetixAPI)
