from time import sleep

import xmltodict

from core.logger import logger
from .acunetix_api import AcunetixAPI


class AcunetixScaner:
    def __init__(self, settings):
        self.acunetix_api = AcunetixAPI(settings)
        self.scan_id = None
        self.result_id = None
        self.settings = settings

    def scan(self, domain=None, options=None, scan_id=None):
        try:
            if scan_id is not None:
                self.scan_id = scan_id
                self.result_id = self.acunetix_api.results_scan(self.scan_id)
                if self.result_id is None:
                    return None
                return self.scan_id
            self.scan_id = self.acunetix_api.start_scan(url=domain, options=options)
            if self.scan_id is None:
                return None
            sleep(5)
            self.result_id = self.acunetix_api.results_scan(self.scan_id)
            if self.result_id is None:
                return None
        except:
            return None
        return self.scan_id

    def check_stop(self, scan_id=None):
        if scan_id is None:
            if self.scan_id is None:
                return -1
            scan_id = self.scan_id
        try:
            job_status = self.acunetix_api.get_status(scan_id)
            print job_status
        except:
            print "error : job_status"
            return -1
        if job_status == -1:
            return -1
        if job_status == "completed":
            try:
                check_error = self.acunetix_api.statistics_scan(scan_id)
                if "scanning_app" in check_error:
                    for check in check_error["scanning_app"]["wvs"]["main"]["messages"]:
                        if check["kind"] == "aborted" or check["kind"] == "failed":
                            return -1
            except:
                pass
            return 1
        if job_status == "failed" or job_status == "aborted":
            return -1
        return 0

    def stop_scan(self, scan_id=None):
        if scan_id is None:
            scan_id = self.scan_id
        return self.acunetix_api.stop_scan(scan_id)

    def logout(self):
        self.acunetix_api.logout()

    def get_list_vuln(self):
        return self.acunetix_api.vulnerabilities(scan_id=self.scan_id, result_id=self.result_id)

    def get_vuln_info(self, vuln_id):
        return self.acunetix_api.vulnerabilities_info(scan_id=self.scan_id, result_id=self.result_id, vuln_id=vuln_id)

    def delete_target(self):
        self.acunetix_api.delete_target()

    def create_report(self, scan_id=None):
        if scan_id is None:
            scan_id = self.scan_id
        try:
            report_xml = self.acunetix_api.getreports(scan_id)
            if report_xml is None:
                return None
            try:
                _json_object = xmltodict.parse(report_xml)
            except Exception as err:
                logger.error("Convert xml to json {0} ".format(str(err)))

                return None
            try:
                _scan_result = {"basic_info": {}, "alert_info": []}
                if "ScanGroup" in _json_object:
                    if "Scan" in _json_object["ScanGroup"]:
                        _data = _json_object["ScanGroup"]["Scan"]
                        url = ""
                        if "StartURL" in _data:
                            _scan_result["basic_info"]["StartURL"] = _data["StartURL"]
                            url = _data["StartURL"]
                        if "StartTime" in _data: _scan_result["basic_info"]["StartTime"] = _data["StartTime"]
                        if "FinishTime" in _data: _scan_result["basic_info"]["FinishTime"] = _data["FinishTime"]
                        if "Banner" in _data: _scan_result["basic_info"]["Banner"] = _data["Banner"]
                        if "Os" in _data: _scan_result["basic_info"]["Os"] = _data["Os"]
                        if "WebServer" in _data: _scan_result["basic_info"]["WebServer"] = _data["WebServer"]
                        if "Technologies" in _data: _scan_result["basic_info"]["Technologies"] = _data["Technologies"]
                        if "Crawler" in _data:
                            _scan_result["basic_info"]["Crawler"] = _data["Crawler"]
                            if "SiteFiles" in _scan_result["basic_info"]["Crawler"]:
                                try:
                                    if "SiteFile" in _data["Crawler"]["SiteFiles"]:
                                        _scan_result["basic_info"]["Crawler"]["SiteFiles"] = \
                                            _data["Crawler"]["SiteFiles"][
                                                "SiteFile"]
                                except:
                                    _scan_result["basic_info"]["Crawler"]["SiteFiles"] = []
                                    print "---------"
                                    pass
                        _reported_items = None
                        _scan_result["basic_info"]["TotalAlert"] = 0
                        if "ReportItems" in _data:
                            if _data["ReportItems"] is not None:
                                if "ReportItem" in _data["ReportItems"]:
                                    if type(_data["ReportItems"]["ReportItem"]) == type([1, 2]):
                                        _reported_items = _data["ReportItems"]["ReportItem"]
                                    else:
                                        _reported_items = [_data["ReportItems"]["ReportItem"]]
                                    _scan_result["basic_info"]["TotalAlert"] = len(_reported_items)

                        else:
                            _scan_result["basic_info"]["TotalAlert"] = 0
                        if _reported_items is not None:
                            severity_map = {
                                "high": 3,
                                "medium": 2,
                                "low": 1,
                                "information": 0,
                                "informational": 0
                            }
                            if "https" in url:
                                port = 443
                            elif "http" in url:
                                port = 80
                            else:
                                port = 0
                            for vuln in _reported_items:
                                severity = severity_map[vuln["Severity"]]
                                vuln_info = {
                                    "name": vuln["Name"],
                                    "synopsis": "",
                                    "description": vuln["Description"],
                                    "family": "",
                                    "impact": "",
                                    "solution": "",
                                    "ref": [],
                                    "cve": [],
                                    "cvss": "",
                                    "severity": severity,
                                    "protocol": str(port) + "/tcp",
                                    "host_vuln": {
                                        "attack_details": "",
                                        "port": port,
                                        "request": "",
                                        "output": "",
                                        "affects": ""
                                    }}
                                if "Impact" in vuln:
                                    vuln_info["impact"] = vuln["Impact"]
                                if "Affects" in vuln:
                                    vuln_info["host_vuln"]["affects"] = vuln["Affects"]
                                if "Details" in vuln:
                                    vuln_info["host_vuln"]["attack_details"] = vuln["Details"]
                                if "CWE" in vuln:
                                    if "#text" in vuln["CWE"]:
                                        vuln_info["cve"].append(vuln["CWE"]["#text"])
                                if "References" in vuln:
                                    if vuln["References"] is not None and "Reference" in vuln["References"]:
                                        if isinstance(vuln["References"]["Reference"], list):
                                            for ref in vuln["References"]["Reference"]:
                                                vuln_info["ref"].append(ref["URL"])
                                        elif isinstance(vuln["References"]["Reference"], dict):
                                            vuln_info["ref"].append(vuln["References"]["Reference"]["URL"])
                                if "Recommendation" in vuln:
                                    vuln_info["solution"] = vuln["Recommendation"]
                                if "CVSS" in vuln:
                                    vuln_info["cvss"] = vuln["CVSS"]["Score"]
                                if "TechnicalDetails" in vuln:
                                    vuln_info["host_vuln"]["request"] = vuln["TechnicalDetails"]["Request"]
                                    vuln_info["host_vuln"]["output"] = vuln["TechnicalDetails"]["Response"]
                                _scan_result["alert_info"].append(vuln_info)
            except Exception as ex:
                logger.error("Convert xml to json  {0}".format(str(ex)))
                return None
            return _scan_result
        except Exception as ex:
            logger.error("Error create report: " + str(ex), plugin=self.settings["name"])
            return None
            pass

    def crawldata_scan(self, loc_id=0):
        return self.acunetix_api.crawldata_scan(scan_id=self.scan_id, loc_id=loc_id, result_id=self.result_id)
